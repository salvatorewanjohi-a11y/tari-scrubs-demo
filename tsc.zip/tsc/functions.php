<?php
/**
 * Tari Scrubs & Supplies child theme.
 */

const TSC_FREE_DELIVERY = 5000; // KSh, keep in step with the Free Nairobi Delivery shipping method.
const TSC_EMBROIDERY    = 500;  // KSh added per item for name & title embroidery.
const TSC_LOGO          = 700;  // KSh added per item for a hospital / institution logo.
const TSC_BULK_FREE     = 10;   // Name & title embroidery is free when the cart has this many embroiderable items.
const TSC_WHATSAPP      = '254708988070';
const TSC_LOW_STOCK     = 3;
const TSC_EMBROIDER_CATS = [ 'scrub-sets', 'lab-coats', 'nurse-uniforms' ];

add_action( 'wp_enqueue_scripts', function () {
	$dir = get_stylesheet_directory();
	$uri = get_stylesheet_directory_uri();
	wp_enqueue_style( 'tsc-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@600;700;800&display=swap', [], null );
	wp_enqueue_style( 'tsc', get_stylesheet_uri(), [], filemtime( $dir . '/style.css' ) );
	wp_enqueue_script( 'tsc', $uri . '/assets/tsc.js', [], filemtime( $dir . '/assets/tsc.js' ), true );
	wp_localize_script( 'tsc', 'TSC', [
		'freeAt'    => TSC_FREE_DELIVERY,
		'store'     => esc_url_raw( rest_url( 'wc/store/v1/' ) ),
		'shop'      => esc_url_raw( wc_get_page_permalink( 'shop' ) ),
	] );
} );

add_action( 'enqueue_block_editor_assets', function () {
	wp_enqueue_style( 'tsc-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@600;700;800&display=swap', [], null );
} );
add_action( 'after_setup_theme', function () {
	add_editor_style( 'style.css' );
} );

/* -------------------------------------------------------------------------
 * Colours and sizes
 * ---------------------------------------------------------------------- */

/**
 * Swatch colour for a colour name. Anything unknown gets a neutral grey.
 */
function tsc_colour_css( $name ) {
	$map = [
		'caribbean blue'      => '#0F7C9C',
		'ocean blue'          => '#14639E',
		'olive (kenyan trim)' => 'linear-gradient(135deg,#5E6B3A 64%,#E53935 64% 74%,#1E88E5 74% 84%,#FDD835 84%)',
		'black (teal piping)' => 'linear-gradient(135deg,#15171A 72%,#3FB6C6 72%)',
		'valentino pink'      => '#E0236F',
		'slate blue'          => '#5A6178',
		'navy'                => '#1B2A4A',
		'jade green'          => '#14A08A',
		'hot pink'            => '#E91E63',
		'beige'               => '#D9C5A6',
		'petrol blue'         => '#1D4E5E',
		'brown'               => '#7A5A3C',
		'royal blue'   => '#1F4FB5',
		'navy blue'    => '#1B2A4A',
		'ceil blue'    => '#8FB3D9',
		'sky blue'     => '#7FB8E6',
		'pastel blue'  => '#A9C6E8',
		'turquoise'    => '#1FB5C9',
		'mauve'        => '#E0739B',
		'peach'        => '#F6C9CF',
		'jungle green' => '#3F5E3C',
		'floral'       => 'conic-gradient(#fff 0 25%,#B58BD6 0 50%,#fff 0 75%,#F4A7C0 0)',
		'galaxy blue'  => '#2A3F8F',
		'blue'         => '#1F6FD1',
		'wine'         => '#6D1F3B',
		'maroon'       => '#8A1F45',
		'purple'       => '#5B2A86',
		'surgical green' => '#0F7A5C',
		'hunter green' => '#14514A',
		'green'        => '#2E9E5B',
		'teal'         => '#0F6E70',
		'mint'         => '#A8DCCB',
		'charcoal'     => '#3D4248',
		'gray'         => '#9AA3AD',
		'grey'         => '#8E949B',
		'black'        => '#15171A',
		'white'        => '#FFFFFF',
		'red'          => '#C62839',
		'magenta'      => '#C2185B',
		'coral pink'   => '#F28C82',
		'eggplant'     => '#4A2545',
		'plum'         => '#7B1F5E',
		'lilac'        => '#B9A2D6',
		'mustard'      => '#D9A21B',
		'olive'        => '#5E6B4E',
		'seafoam'      => '#6CC7B5',
		'pewter'       => '#6B7078',
		'pink'         => '#F4A7C0',
		'orange'       => '#F07A1A',
		'gold'         => '#C9A43A',
		'silver'       => '#C0C4C9',
		'white & navy' => 'linear-gradient(135deg,#fff 50%,#1B2A4A 50%)',
		'printed'      => 'conic-gradient(#F4A7C0 0 25%,#8FB3D9 0 50%,#A8DCCB 0 75%,#F0C987 0)',
	];
	return $map[ strtolower( trim( html_entity_decode( $name ) ) ) ] ?? '#B8C2CC';
}

/**
 * Colour/size options a shopper chooses on the product page (attributes that are not variations).
 *
 * @return array{colour: WP_Term[], size: WP_Term[]}
 */
function tsc_choices( WC_Product $product ) {
	$out = [ 'colour' => [], 'size' => [] ];
	$attrs = $product->get_attributes();
	foreach ( [ 'colour', 'size' ] as $key ) {
		$tax = "pa_$key";
		if ( isset( $attrs[ $tax ] ) && ! $attrs[ $tax ]->get_variation() ) {
			$out[ $key ] = wc_get_product_terms( $product->get_id(), $tax, [ 'orderby' => 'menu_order' ] );
		}
	}
	return $out;
}

function tsc_can_embroider( WC_Product $product ) {
	return has_term( TSC_EMBROIDER_CATS, 'product_cat', $product->get_id() );
}

function tsc_needs_choices( WC_Product $product ) {
	$c = tsc_choices( $product );
	return $product->is_type( 'variable' ) || $c['colour'] || $c['size'];
}

/* -------------------------------------------------------------------------
 * Product page: swatches, sizes, embroidery
 * ---------------------------------------------------------------------- */

add_action( 'woocommerce_before_add_to_cart_quantity', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$c = tsc_choices( $product );

	if ( $c['colour'] ) {
		$single = count( $c['colour'] ) === 1;
		echo '<fieldset class="tsc-opt tsc-opt--colour"><legend>Colour: <strong data-tsc-colour-label>' . ( $single ? esc_html( $c['colour'][0]->name ) : 'choose one' ) . '</strong></legend><div class="tsc-swatches">';
		// Which gallery photo shows each colour (0 = main photo), set per product.
		$photos = (array) $product->get_meta( '_tsc_colour_images' );
		foreach ( $c['colour'] as $t ) {
			printf(
				'<label class="tsc-swatch" title="%1$s"><input type="radio" name="tsc_colour" value="%1$s" required%3$s%4$s><span style="background:%2$s"></span><em class="screen-reader-text">%1$s</em></label>',
				esc_attr( $t->name ),
				esc_attr( tsc_colour_css( $t->name ) ),
				$single ? ' checked' : '',
				isset( $photos[ $t->name ] ) ? ' data-tsc-photo="' . (int) $photos[ $t->name ] . '"' : ''
			);
		}
		echo '</div></fieldset>';
	}

	if ( $c['size'] ) {
		echo '<fieldset class="tsc-opt tsc-opt--size"><legend>Size: <strong data-tsc-size-label>choose one</strong>';
		if ( ! has_term( [ 'footwear' ], 'product_cat', $product->get_id() ) ) {
			echo ' <button type="button" class="tsc-link" data-tsc-open="tsc-size-guide">Size guide</button>';
		}
		echo '</legend><div class="tsc-sizes">';
		foreach ( $c['size'] as $t ) {
			printf( '<label class="tsc-size"><input type="radio" name="tsc_size" value="%1$s" required><span>%1$s</span></label>', esc_attr( $t->name ) );
		}
		echo '</div></fieldset>';
	}

	if ( tsc_can_embroider( $product ) ) {
		?>
		<p class="tsc-emb-intro"><strong>Personalise it</strong> <span>Free name &amp; title embroidery when you order <?php echo (int) TSC_BULK_FREE; ?> or more sets.</span></p>
		<div class="tsc-emb" data-tsc-emb>
			<label class="tsc-emb__toggle"><input type="checkbox" name="tsc_emb" value="1" data-tsc-emb-toggle>
				<span><strong>Add name &amp; title embroidery</strong> <em>+ KSh <?php echo number_format( TSC_EMBROIDERY ); ?></em><small>Your name and title stitched on the chest</small></span>
			</label>
			<div class="tsc-emb__fields" hidden>
				<label>Name &amp; qualifications<input type="text" name="tsc_emb_text" maxlength="30" placeholder="e.g. Dr. S. Wanjiru, MBChB" data-tsc-emb-text></label>
				<div class="tsc-emb__row">
					<label>Thread colour<select name="tsc_emb_thread" data-tsc-emb-thread>
						<?php foreach ( [ 'White', 'Navy', 'Black', 'Gold', 'Sky Blue', 'Royal Blue' ] as $t ) echo '<option>' . esc_html( $t ) . '</option>'; ?>
					</select></label>
					<label>Position<select name="tsc_emb_side" data-tsc-emb-side><option>Left chest</option><option>Right chest</option></select></label>
				</div>
				<div class="tsc-emb__preview" data-tsc-emb-preview><span>Your name here</span></div>
			</div>
		</div>
		<div class="tsc-emb" data-tsc-logo>
			<label class="tsc-emb__toggle"><input type="checkbox" name="tsc_logo" value="1" data-tsc-logo-toggle>
				<span><strong>Add hospital / institution logo</strong> <em>+ KSh <?php echo number_format( TSC_LOGO ); ?></em><small>Your hospital, clinic or school logo on the sleeve or chest</small></span>
			</label>
			<div class="tsc-emb__fields" hidden>
				<label>Hospital, clinic or school<input type="text" name="tsc_logo_name" maxlength="60" placeholder="e.g. Kenyatta National Hospital" data-tsc-logo-name></label>
				<p class="tsc-small">After you order, send us the logo on WhatsApp (<?php echo esc_html( tsc_phone_shown() ); ?>) and we'll confirm how it will look before stitching.</p>
			</div>
		</div>
		<?php
	}
} );

// No published price (clinical packages): ask on WhatsApp instead of adding to the cart.
// (The product page is a block template, so this rides on the add-to-cart block.)
add_filter( 'render_block_woocommerce/add-to-cart-form', function ( $content ) {
	$product = is_product() ? wc_get_product( get_queried_object_id() ) : null;
	if ( ! $product || '' !== $product->get_price() ) {
		return $content;
	}
	$msg = 'Hi Tari Scrubs, what is the price of the ' . $product->get_name() . '?';
	return $content . '<div class="tsc-ask-box"><p><strong>Ask for price</strong> Stethoscope package prices change with stock, so we confirm today\'s price and colours on WhatsApp.</p><a class="wp-element-button tsc-wa-btn" href="' . esc_url( 'https://wa.me/' . TSC_WHATSAPP . '?text=' . rawurlencode( $msg ) ) . '" target="_blank" rel="noopener">Ask for price on WhatsApp</a></div>';
} );

// Size guide pop-up on product pages, and as a page of its own.
function tsc_size_guide_html() {
	$rows = [
		[ 'XS', '82–87', '66–71', '68' ],
		[ 'S', '88–93', '72–77', '70' ],
		[ 'M', '94–100', '78–84', '72' ],
		[ 'L', '101–108', '85–92', '74' ],
		[ 'XL', '109–116', '93–100', '76' ],
		[ 'XXL', '117–124', '101–108', '78' ],
	];
	$h = '<div class="tsc-size-table"><table><thead><tr><th>Size</th><th>Chest (cm)</th><th>Waist (cm)</th><th>Top length (cm)</th></tr></thead><tbody>';
	foreach ( $rows as $r ) {
		$h .= '<tr><td><strong>' . $r[0] . '</strong></td><td>' . $r[1] . '</td><td>' . $r[2] . '</td><td>' . $r[3] . '</td></tr>';
	}
	$h .= '</tbody></table></div>';
	$h .= '<p class="tsc-small">Our scrubs have a relaxed unisex fit. Measure around the fullest part of your chest and your natural waist. Between sizes? Go one up for a relaxed fit, or WhatsApp us your height and usual size and we\'ll help you choose.</p>';
	return $h;
}
add_shortcode( 'tsc_size_guide', 'tsc_size_guide_html' );

add_action( 'wp_footer', function () {
	if ( ! is_product() ) {
		return;
	}
	echo '<dialog id="tsc-size-guide" class="tsc-dialog"><form method="dialog"><button class="tsc-dialog__close" aria-label="Close">×</button></form><h2>Size guide</h2>' . tsc_size_guide_html() . '</dialog>';
} );

add_filter( 'woocommerce_add_to_cart_validation', function ( $ok, $product_id ) {
	$product = wc_get_product( $product_id );
	if ( ! $product ) {
		return $ok;
	}
	$c = tsc_choices( $product );
	if ( count( $c['colour'] ) > 1 && empty( $_REQUEST['tsc_colour'] ) ) {
		wc_add_notice( 'Please choose a colour.', 'error' );
		return false;
	}
	if ( $c['size'] && empty( $_REQUEST['tsc_size'] ) ) {
		wc_add_notice( 'Please choose a size.', 'error' );
		return false;
	}
	if ( ! empty( $_REQUEST['tsc_emb'] ) && trim( wp_unslash( $_REQUEST['tsc_emb_text'] ?? '' ) ) === '' ) {
		wc_add_notice( 'Please enter the name to embroider, or untick embroidery.', 'error' );
		return false;
	}
	if ( ! empty( $_REQUEST['tsc_logo'] ) && trim( wp_unslash( $_REQUEST['tsc_logo_name'] ?? '' ) ) === '' ) {
		wc_add_notice( 'Please enter the hospital or school whose logo we should add, or untick the logo.', 'error' );
		return false;
	}
	return $ok;
}, 10, 2 );

add_filter( 'woocommerce_add_cart_item_data', function ( $data, $product_id ) {
	$product = wc_get_product( $product_id );
	if ( ! $product ) {
		return $data;
	}
	$c = tsc_choices( $product );
	$clean = fn( $k ) => sanitize_text_field( wp_unslash( $_REQUEST[ $k ] ?? '' ) );
	if ( $c['colour'] ) {
		$data['tsc_colour'] = $clean( 'tsc_colour' ) ?: $c['colour'][0]->name;
	}
	if ( $c['size'] && $clean( 'tsc_size' ) ) {
		$data['tsc_size'] = $clean( 'tsc_size' );
	}
	if ( ! empty( $_REQUEST['tsc_emb'] ) && tsc_can_embroider( $product ) ) {
		$data['tsc_emb'] = [
			'text'   => mb_substr( $clean( 'tsc_emb_text' ), 0, 30 ),
			'thread' => $clean( 'tsc_emb_thread' ) ?: 'White',
			'side'   => $clean( 'tsc_emb_side' ) ?: 'Left chest',
		];
	}
	if ( ! empty( $_REQUEST['tsc_logo'] ) && tsc_can_embroider( $product ) ) {
		$data['tsc_logo'] = mb_substr( $clean( 'tsc_logo_name' ), 0, 60 );
	}
	return $data;
}, 10, 2 );

// Items in the cart that can be embroidered (scrubs, lab coats, nurse uniforms), counting quantities.
function tsc_embroiderable_count() {
	if ( ! WC()->cart ) {
		return 0;
	}
	$n = 0;
	foreach ( WC()->cart->get_cart() as $item ) {
		if ( has_term( TSC_EMBROIDER_CATS, 'product_cat', $item['product_id'] ) ) {
			$n += (int) $item['quantity'];
		}
	}
	return $n;
}
function tsc_bulk_free() {
	return tsc_embroiderable_count() >= TSC_BULK_FREE;
}

function tsc_phone_shown() {
	return '0' . substr( TSC_WHATSAPP, 3, 3 ) . ' ' . substr( TSC_WHATSAPP, 6, 3 ) . ' ' . substr( TSC_WHATSAPP, 9 );
}

function tsc_item_lines( array $item ) {
	$lines = [];
	if ( ! empty( $item['tsc_colour'] ) ) $lines['Colour'] = $item['tsc_colour'];
	if ( ! empty( $item['tsc_size'] ) ) $lines['Size'] = $item['tsc_size'];
	if ( ! empty( $item['tsc_emb'] ) ) {
		$e = $item['tsc_emb'];
		$fee = tsc_bulk_free() ? 'free on ' . TSC_BULK_FREE . '+ sets' : '+KSh ' . number_format( TSC_EMBROIDERY );
		$lines['Embroidery'] = '"' . $e['text'] . '" – ' . $e['thread'] . ' thread, ' . strtolower( $e['side'] ) . ' (' . $fee . ')';
	}
	if ( ! empty( $item['tsc_logo'] ) ) {
		$lines['Logo'] = $item['tsc_logo'] . ' (+KSh ' . number_format( TSC_LOGO ) . ')';
	}
	return $lines;
}

add_filter( 'woocommerce_get_item_data', function ( $out, $item ) {
	foreach ( tsc_item_lines( $item ) as $k => $v ) {
		$out[] = [ 'key' => $k, 'value' => $v ];
	}
	return $out;
}, 10, 2 );

add_action( 'woocommerce_before_calculate_totals', function ( $cart ) {
	$name_fee = tsc_bulk_free() ? 0 : TSC_EMBROIDERY;
	foreach ( $cart->get_cart() as $item ) {
		if ( empty( $item['tsc_emb'] ) && empty( $item['tsc_logo'] ) ) {
			continue;
		}
		$fresh = wc_get_product( $item['variation_id'] ?: $item['product_id'] );
		if ( $fresh ) {
			$extra = ( empty( $item['tsc_emb'] ) ? 0 : $name_fee ) + ( empty( $item['tsc_logo'] ) ? 0 : TSC_LOGO );
			$item['data']->set_price( (float) $fresh->get_price() + $extra );
		}
	}
}, 20 );

add_action( 'woocommerce_checkout_create_order_line_item', function ( $line, $key, $item ) {
	foreach ( tsc_item_lines( $item ) as $k => $v ) {
		$line->add_meta_data( $k, $v );
	}
}, 10, 3 );

// "Complete the set": the product's upsells, under the add-to-cart button.
add_action( 'woocommerce_after_add_to_cart_form', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$ids = array_slice( $product->get_upsell_ids(), 0, 3 );
	if ( ! $ids ) {
		return;
	}
	echo '<div class="tsc-set"><p class="tsc-set__title">Complete the set</p>';
	foreach ( $ids as $id ) {
		$p = wc_get_product( $id );
		if ( ! $p || ! $p->is_visible() ) continue;
		printf(
			'<a class="tsc-set__item" href="%s">%s<span><strong>%s</strong>%s</span><em>View</em></a>',
			esc_url( $p->get_permalink() ),
			$p->get_image( 'thumbnail' ),
			esc_html( $p->get_name() ),
			'' === $p->get_price() ? '<span class="tsc-ask">Ask for price</span>' : $p->get_price_html()
		);
	}
	echo '</div>';
} );

// Fabric & care and delivery tabs.
add_filter( 'woocommerce_product_tabs', function ( $tabs ) {
	global $product;
	if ( ! $product ) {
		return $tabs;
	}
	$fabric = get_post_meta( $product->get_id(), '_tsc_fabric', true );
	if ( $fabric ) {
		$tabs['tsc_fabric'] = [
			'title'    => 'Fabric & care',
			'priority' => 15,
			'callback' => function () use ( $fabric ) {
				echo wpautop( wp_kses_post( $fabric ) );
			},
		];
	}
	$tabs['tsc_delivery'] = [
		'title'    => 'Delivery & pickup',
		'priority' => 25,
		'callback' => function () {
			echo '<ul><li><strong>Express Nairobi delivery:</strong> same-day dispatch for orders confirmed before 3 PM, KSh 300. Free on orders over KSh ' . number_format( TSC_FREE_DELIVERY ) . '.</li><li><strong>Upcountry parcel:</strong> 1–3 days to any county, KSh 500.</li><li><strong>Pick-up point:</strong> free from our pick-up point in Nairobi. We\'ll WhatsApp you when your order is ready and where to collect it.</li><li>Embroidered items are usually ready in 1–2 working days. Bulk and group orders: ask us for a timeline.</li></ul>';
		},
	];
	unset( $tabs['additional_information'] );
	return $tabs;
}, 20 );

/* -------------------------------------------------------------------------
 * Product cards
 * ---------------------------------------------------------------------- */

function tsc_card_product( $instance ) {
	$id = $instance->context['postId'] ?? get_the_ID();
	return $id && ! is_admin() ? wc_get_product( $id ) : null;
}

// Hover image (first gallery photo) and wishlist heart on product images.
add_filter( 'render_block_woocommerce/product-image', function ( $content, $block, $instance ) {
	$product = tsc_card_product( $instance );
	if ( ! $product || empty( $block['attrs']['isDescendentOfQueryLoop'] ) ) {
		return $content;
	}
	$gallery = $product->get_gallery_image_ids();
	if ( $gallery ) {
		$alt = wp_get_attachment_image( $gallery[0], 'woocommerce_thumbnail', false, [ 'class' => 'tsc-alt-img', 'alt' => '', 'loading' => 'lazy' ] );
		$content = preg_replace( '#(<img[^>]*>)#', '$1' . $alt, $content, 1 );
	}
	$heart = sprintf(
		'<button type="button" class="tsc-heart" data-tsc-wish="%d" aria-label="Save %s to wishlist" aria-pressed="false"><svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M12 20.3 4.6 13a4.8 4.8 0 0 1 6.8-6.8l.6.6.6-.6a4.8 4.8 0 0 1 6.8 6.8Z"/></svg></button>',
		$product->get_id(),
		esc_attr( $product->get_name() )
	);
	$pos = strrpos( $content, '</div>' );
	return $pos === false ? $content : substr_replace( $content, $heart . '</div>', $pos, 6 );
}, 10, 3 );

// Spec badge above the price, colour dots below it.
add_filter( 'render_block_woocommerce/product-price', function ( $content, $block, $instance ) {
	$product = tsc_card_product( $instance );
	if ( ! $product ) {
		return $content;
	}
	$before = '';
	$spec = get_post_meta( $product->get_id(), '_tsc_spec', true );
	if ( $spec ) {
		$before .= '<span class="tsc-badge">' . esc_html( $spec ) . '</span>';
	}
	if ( ! $product->is_in_stock() ) {
		$before .= '<span class="tsc-badge tsc-badge--out">Out of stock</span>';
	} elseif ( $product->managing_stock() && (int) $product->get_stock_quantity() <= TSC_LOW_STOCK ) {
		$before .= '<span class="tsc-badge tsc-badge--low">Only ' . (int) $product->get_stock_quantity() . ' left</span>';
	}
	if ( '' === $product->get_price() ) {
		$content = '<div class="wc-block-components-product-price tsc-ask">Ask for price</div>';
	}
	$after = '';
	if ( ! empty( $block['attrs']['isDescendentOfQueryLoop'] ) ) {
		$colours = tsc_choices( $product )['colour'];
		if ( count( $colours ) > 1 ) {
			$after = '<div class="tsc-dots" aria-label="' . count( $colours ) . ' colours">';
			foreach ( array_slice( $colours, 0, 7 ) as $t ) {
				$after .= '<span title="' . esc_attr( $t->name ) . '" style="background:' . esc_attr( tsc_colour_css( $t->name ) ) . '"></span>';
			}
			if ( count( $colours ) > 7 ) {
				$after .= '<em>+' . ( count( $colours ) - 7 ) . '</em>';
			}
			$after .= '</div>';
		}
	}
	return ( $before ? '<div class="tsc-badges">' . $before . '</div>' : '' ) . $content . $after;
}, 10, 3 );

// Sale badge shows the saving, e.g. "−18%".
add_filter( 'render_block_woocommerce/product-sale-badge', function ( $content, $block, $instance ) {
	$product = tsc_card_product( $instance );
	if ( ! $product || ! $product->is_on_sale() ) {
		return $content;
	}
	$pct = 0;
	foreach ( $product->is_type( 'variable' ) ? $product->get_available_variations( 'objects' ) : [ $product ] as $p ) {
		$reg  = (float) $p->get_regular_price();
		$sale = (float) $p->get_sale_price();
		if ( $reg > 0 && $sale > 0 ) {
			$pct = max( $pct, round( ( $reg - $sale ) / $reg * 100 ) );
		}
	}
	return $pct ? preg_replace( '#>\s*Sale\s*<#', '>−' . $pct . '%<', $content, 1 ) : $content;
}, 10, 3 );

// Products that need a colour or size go to the product page instead of adding straight to the cart.
add_filter( 'woocommerce_product_add_to_cart_text', function ( $text, $product ) {
	if ( '' === $product->get_price() ) {
		return 'Ask for price';
	}
	if ( $product->is_purchasable() && $product->is_in_stock() && tsc_needs_choices( $product ) ) {
		return tsc_choices( $product )['size'] ? 'Choose size' : 'Choose options';
	}
	return $text;
}, 10, 2 );
add_filter( 'woocommerce_product_add_to_cart_url', function ( $url, $product ) {
	// On a product page this also covers the related and upsell cards, so compare with the page's own product.
	return tsc_needs_choices( $product ) && get_queried_object_id() !== $product->get_id() ? $product->get_permalink() : $url;
}, 10, 2 );
add_filter( 'woocommerce_product_supports', function ( $supports, $feature, $product ) {
	return $feature === 'ajax_add_to_cart' && tsc_needs_choices( $product ) ? false : $supports;
}, 10, 3 );

/* -------------------------------------------------------------------------
 * Home page sections
 * ---------------------------------------------------------------------- */

add_shortcode( 'tsc_roles', function () {
	$roles = [
		'doctors-interns'          => [ 'Doctors & Interns', 'role-doctors' ],
		'medical-students'         => [ 'Medical Students', 'role-students' ],
		'nurses-clinical-officers' => [ 'Nurses & Clinical Officers', 'role-nurses' ],
		'theatre-wards'            => [ 'Theatre & Ward Staff', 'role-theatre' ],
	];
	$h = '<div class="tsc-roles">';
	foreach ( $roles as $slug => [ $name, $img ] ) {
		$term = get_term_by( 'slug', $slug, 'product_tag' );
		if ( ! $term ) continue;
		$h .= sprintf(
			'<a class="tsc-role" href="%s"><img src="%s" alt="" loading="lazy" width="300" height="400"><span><strong>%s</strong><em>%d products</em></span></a>',
			esc_url( get_term_link( $term ) ),
			esc_url( get_stylesheet_directory_uri() . "/assets/photos/$img.webp" ),
			esc_html( $name ),
			(int) $term->count
		);
	}
	return $h . '</div>';
} );

add_shortcode( 'tsc_colours', function () {
	$terms = get_terms( [ 'taxonomy' => 'pa_colour', 'hide_empty' => true, 'orderby' => 'count', 'order' => 'DESC', 'number' => 12 ] );
	if ( is_wp_error( $terms ) || ! $terms ) {
		return '';
	}
	$h = '<div class="tsc-colours"><p class="tsc-colours__label">Shop by colour</p><div class="tsc-colours__list">';
	foreach ( $terms as $t ) {
		$h .= sprintf(
			'<a href="%s"><span style="background:%s"></span>%s</a>',
			esc_url( get_term_link( $t ) ),
			esc_attr( tsc_colour_css( $t->name ) ),
			esc_html( $t->name )
		);
	}
	return $h . '</div></div>';
} );

// Category and colour chips above shop, category, colour and search results.
add_shortcode( 'tsc_filters', function () {
	$current = get_queried_object();
	$cur_id  = $current instanceof WP_Term ? $current->term_id : 0;
	$h = '<nav class="tsc-filters" aria-label="Filter products"><div class="tsc-filters__row">';
	$h .= '<a class="tsc-chip' . ( is_shop() ? ' is-on' : '' ) . '" href="' . esc_url( wc_get_page_permalink( 'shop' ) ) . '">All</a>';
	foreach ( get_terms( [ 'taxonomy' => 'product_cat', 'hide_empty' => true, 'exclude' => [ (int) get_option( 'default_product_cat' ) ], 'orderby' => 'term_id' ] ) as $t ) {
		$h .= sprintf( '<a class="tsc-chip%s" href="%s">%s <em>%d</em></a>', $t->term_id === $cur_id ? ' is-on' : '', esc_url( get_term_link( $t ) ), esc_html( $t->name ), (int) $t->count );
	}
	$h .= '</div><div class="tsc-filters__row tsc-filters__row--colours"><span>Colour</span>';
	foreach ( get_terms( [ 'taxonomy' => 'pa_colour', 'hide_empty' => true, 'orderby' => 'count', 'order' => 'DESC', 'number' => 14 ] ) as $t ) {
		$h .= sprintf(
			'<a class="tsc-colour-dot%s" href="%s" title="%s" aria-label="%3$s"><span style="background:%s"></span></a>',
			$t->term_id === $cur_id ? ' is-on' : '',
			esc_url( get_term_link( $t ) ),
			esc_attr( $t->name ),
			esc_attr( tsc_colour_css( $t->name ) )
		);
	}
	return $h . '</div></nav>';
} );

add_shortcode( 'tsc_wishlist', function () {
	return '<div class="tsc-wishlist" data-tsc-wishlist><p class="tsc-small">Loading your saved items…</p></div>';
} );

/* -------------------------------------------------------------------------
 * Cart, checkout, order confirmation
 * ---------------------------------------------------------------------- */

function tsc_freebar_html() {
	$total = WC()->cart ? (float) WC()->cart->get_displayed_subtotal() : 0;
	$left  = max( 0, TSC_FREE_DELIVERY - $total );
	$pct   = min( 100, round( $total / TSC_FREE_DELIVERY * 100 ) );
	$msg   = $left > 0
		? 'Add <strong>KSh ' . number_format( $left ) . '</strong> more for <strong>free Nairobi delivery</strong>'
		: '<strong>You\'ve unlocked free Nairobi delivery!</strong>';
	return '<div class="tsc-freebar" data-tsc-freebar>' . $msg . '<div class="tsc-freebar__track"><div class="tsc-freebar__fill" style="width:' . $pct . '%"></div></div></div>';
}
add_filter( 'render_block_woocommerce/cart', fn( $c ) => tsc_freebar_html() . $c );
add_filter( 'render_block_woocommerce/mini-cart-contents', function ( $c ) {
	return preg_replace( '#(<div[^>]*wp-block-woocommerce-filled-mini-cart-contents-block[^>]*>)#', '$1' . tsc_freebar_html(), $c, 1 );
} );

// Designation at checkout, so the shop knows who it's dressing.
add_action( 'woocommerce_init', function () {
	if ( ! function_exists( 'woocommerce_register_additional_checkout_field' ) ) {
		return;
	}
	woocommerce_register_additional_checkout_field( [
		'id'       => 'tsc/designation',
		'label'    => 'Role',
		'location' => 'contact',
		'type'     => 'select',
		'required' => false,
		'options'  => array_map( fn( $v ) => [ 'value' => $v, 'label' => $v ], [ 'Doctor / Intern', 'Nurse', 'Clinical Officer', 'Medical Student', 'Dentist', 'Lab Technologist', 'Pharmacist', 'Other' ] ),
	] );
} );

// WhatsApp order summary on the order confirmation page.
function tsc_whatsapp_order_link( WC_Order $order ) {
	$lines = [ 'Hi Tari Scrubs, I just placed order #' . $order->get_order_number() . ':' ];
	foreach ( $order->get_items() as $item ) {
		$meta = [];
		foreach ( [ 'Colour', 'Size', 'Embroidery', 'Logo' ] as $k ) {
			$v = $item->get_meta( $k );
			if ( $v ) $meta[] = "$k: $v";
		}
		$lines[] = '• ' . $item->get_quantity() . ' × ' . $item->get_name() . ( $meta ? ' (' . implode( '; ', $meta ) . ')' : '' );
	}
	$lines[] = 'Total: KSh ' . number_format( (float) $order->get_total() );
	$lines[] = 'Delivery: ' . $order->get_shipping_method();
	$lines[] = 'Name: ' . $order->get_formatted_billing_full_name() . ', ' . $order->get_billing_phone();
	return 'https://wa.me/' . TSC_WHATSAPP . '?text=' . rawurlencode( implode( "\n", $lines ) );
}
add_filter( 'render_block_woocommerce/order-confirmation-status', function ( $content ) {
	$order_id = absint( get_query_var( 'order-received' ) );
	$order    = $order_id ? wc_get_order( $order_id ) : null;
	if ( ! $order || ! hash_equals( $order->get_order_key(), wc_clean( wp_unslash( $_GET['key'] ?? '' ) ) ) ) {
		return $content;
	}
	return $content . '<div class="tsc-thanks"><p>Your order number is <strong>#' . esc_html( $order->get_order_number() ) . '</strong>. Send us the summary on WhatsApp and we\'ll confirm it straight away.</p><a class="wp-element-button tsc-wa-btn" href="' . esc_attr( tsc_whatsapp_order_link( $order ) ) . '" target="_blank" rel="noopener">Send order on WhatsApp</a></div>';
} );

// Newsletter: store the email and hand over the KSh 300 welcome code.
add_action( 'admin_post_nopriv_tsc_subscribe', 'tsc_subscribe' );
add_action( 'admin_post_tsc_subscribe', 'tsc_subscribe' );
function tsc_subscribe() {
	check_admin_referer( 'tsc_subscribe' );
	$email = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) );
	$back  = wp_get_referer() ?: home_url( '/' );
	if ( ! is_email( $email ) ) {
		wp_safe_redirect( add_query_arg( 'tsc_sub', 'invalid', $back ) . '#newsletter' );
		exit;
	}
	$list = get_option( 'tsc_subscribers', [] );
	$list[ strtolower( $email ) ] = current_time( 'mysql' );
	update_option( 'tsc_subscribers', $list, false );
	wp_safe_redirect( add_query_arg( 'tsc_sub', 'ok', $back ) . '#newsletter' );
	exit;
}

add_shortcode( 'tsc_newsletter', function () {
	$state = sanitize_key( $_GET['tsc_sub'] ?? '' );
	if ( $state === 'ok' ) {
		return '<p class="tsc-news-ok"><strong>Welcome to Tari Scrubs!</strong> Use code <strong class="tsc-wine">TARI300</strong> at checkout for KSh 300 off your first order of KSh 2,500 or more.</p>';
	}
	$err = $state === 'invalid' ? '<p class="tsc-news-err">Please enter a valid email address.</p>' : '';
	return '<form class="tsc-news-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">'
		. '<input type="hidden" name="action" value="tsc_subscribe">'
		. wp_nonce_field( 'tsc_subscribe', '_wpnonce', true, false )
		. '<input type="email" name="email" required placeholder="Your email address" aria-label="Email address">'
		. '<button class="wp-element-button" type="submit">Get KSh 300 off</button>'
		. '</form>' . $err;
} );

// Staff see the subscriber list under WooCommerce.
add_action( 'admin_menu', function () {
	add_submenu_page( 'woocommerce', 'Newsletter subscribers', 'Subscribers', 'manage_woocommerce', 'tsc-subscribers', function () {
		$list = get_option( 'tsc_subscribers', [] );
		echo '<div class="wrap"><h1>Newsletter subscribers (' . count( $list ) . ')</h1><table class="widefat striped"><thead><tr><th>Email</th><th>Signed up</th></tr></thead><tbody>';
		foreach ( array_reverse( $list, true ) as $email => $when ) {
			echo '<tr><td>' . esc_html( $email ) . '</td><td>' . esc_html( $when ) . '</td></tr>';
		}
		echo '</tbody></table></div>';
	} );
} );

// Staff edit the card badge and the fabric & care text on the product screen.
add_action( 'woocommerce_product_options_general_product_data', function () {
	woocommerce_wp_text_input( [ 'id' => '_tsc_spec', 'label' => 'Card badge', 'description' => 'Short label on the product card, e.g. "4-Way Stretch".', 'desc_tip' => true ] );
	woocommerce_wp_textarea_input( [ 'id' => '_tsc_fabric', 'label' => 'Fabric & care', 'rows' => 5 ] );
} );
add_action( 'woocommerce_admin_process_product_object', function ( $product ) {
	foreach ( [ '_tsc_spec' => 'sanitize_text_field', '_tsc_fabric' => 'wp_kses_post' ] as $key => $clean ) {
		if ( isset( $_POST[ $key ] ) ) {
			$product->update_meta_data( $key, $clean( wp_unslash( $_POST[ $key ] ) ) );
		}
	}
} );

/* -------------------------------------------------------------------------
 * Housekeeping
 * ---------------------------------------------------------------------- */

// Kenyan addresses: no postcode, and riders need a phone number.
add_filter( 'woocommerce_get_country_locale', function ( $locale ) {
	$locale['KE']['postcode'] = [ 'required' => false, 'hidden' => true ];
	$locale['KE']['city']     = [ 'label' => 'Area / Estate (e.g. Westlands, Kilimani)' ];
	$locale['KE']['phone']    = [ 'required' => true ];
	return $locale;
} );

// Local preview only: the SQLite layer can't run WooCommerce's stock-reservation query.
// Real hosting uses MySQL, where this never triggers.
if ( isset( $GLOBALS['wpdb'] ) && stripos( get_class( $GLOBALS['wpdb'] ), 'sqlite' ) !== false ) {
	add_filter( 'woocommerce_hold_stock_for_checkout', '__return_false' );
}

// Browser tab icon: the shop's logo.
add_action( 'wp_head', function () {
	if ( has_site_icon() ) {
		return;
	}
	$src = esc_url( get_stylesheet_directory_uri() . '/assets/icon.png' );
	echo "<link rel=\"icon\" href=\"$src\">\n<link rel=\"apple-touch-icon\" href=\"$src\">\n";
} );

// Templates use root-relative links ("/shop/"); point them at the real home URL so the site
// also works from a sub-folder (e.g. the WordPress Playground demo).
add_filter( 'render_block', function ( $content ) {
	$home = trailingslashit( home_url() );
	if ( $home === '/' || ! str_contains( $content, '="/' ) ) {
		return $content;
	}
	return preg_replace( '#\b(href|src)="/(?!/)#', '$1="' . $home, $content );
} );
